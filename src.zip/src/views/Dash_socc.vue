<template>
<v-app>
  <Navbar/>
<v-content>
<div>
<p></p>
<p></p>

    <v-card-title>
     <h1 class="headline font-weight-black pa-2">Dashboard</h1>
      <v-spacer></v-spacer>
      <v-flex xs12 md4>
      <v-text-field v-model="search" append-icon="search" label="Search"  single-line hide-detail></v-text-field>
      </v-flex>
    </v-card-title>
    <v-data-table :headers="headers" :search="search" :items="title" class="elevation-1">
    <template v-slot:items="props">
      <td>{{ props.item.evenum }}</td>
      <td> {{props.item.organization}}</td>
      <td class="text-xs-left">{{ props.item.event}}</td>
      <td class="text-xs-left">{{ props.item.year}}</td>
      <td class="text-xs-left">{{ props.item.sem}}</td>
      <td class="text-xs-left">{{ props.item.datesub}}</td>
      <td><v-flex xs2 sm4 md2>
      <div class="left">
              <v-chip small :class="`${props.item.stat} white--text my-2 caption`">{{ props.item.stat }}</v-chip>
      </div>
      </v-flex>
      </td>
      <td class="justify-center layout px-0">
      </td>
      </template>
      </v-data-table>
       
</div>

</v-content>
</v-app>
</template>

<script>
import Navbar from '@/components/navbar_socc'

export default{
  name: 'Navbar_SOCC',
  components: { Navbar },
  data(){
    return{
      search:'',
      headers: [
          {
            text: 'eReserve#',
            align: 'left',
            sortable: true,
            value: 'evenum'
          },
          { text: 'Organization', value:'organization'},
          { text: 'Event Name', value: 'event' },
          { text: 'Academic Year', value: 'year' },
          { text: 'Semester', value: 'sem' },
          { text: 'Date Submitted', value: 'datesub' },
          { text: 'Status', value: 'stat' }
        ],
title: [
          {
            evenum:'0001',
            organization: 'Org One',
            event: 'Event 1',
            year:'2017-2018',
            sem:'2nd Semester',
            datesub:'January 20, 2018',
            stat:' OSA Approved'
          },
          {
            evenum:'0002',
            organization: 'Org One',
            event: 'Event Name 2',
            year:'2017-2018',
            sem:'2nd Semester',
            datesub:'January 23, 2018',
            stat:'Pending Evaluation'
          },
          {
            evenum:'0003',
             organization: 'Org One',
            event: 'Event Name 3',
            year:'2017-2018',
            sem:'1st Semester',
            datesub:'January 23, 2018',
            stat:'Endorsed to OSA'
          },
           {
            evenum:'0004',
            organization: 'Org One',
            event: 'Event Name 4',
            year:'2017-2018',
            sem:'2nd Semester',
            datesub:'January 23, 2018',
            stat:'Endorsed to OSA'
          },
          {
            evenum:'0005',
            organization: 'Org One',
            event: 'Event Name 5',
            year:'2017-2018',
            sem:'2nd Semester',
            datesub:'January 23, 2018',
            stat:'Denied'
          }
          ]
        }
  }
   
}
</script>

<style>

.v-chip.Approved{
  background: 4px#64DD17
}

.v-chip.Endorsed{
  background: 4px #2E7D32
}

.v-chip.Pending{
  background: 4px #FFC107
}

</style>
